# California Wildfires Map

Mapping the California wildfires using multiple sources and Mapbox.

*Created by George LeVines (<george.levines@gmail.com>)*

*Reporter: George LeVines (<george.levines@gmail.com>)*

## Project goal

*TK: Briefly describe this project*

## Project notes

### Staff involved

*TK: List people & contact info for people involved in the project*

[Responsibility matrix](url-to-responsibility matrix)

[HIRUFF Q&A](url-to-hiruff)

### Data sources

*TK: List access info & contact info for data sources used in the project*

## Technical

*TK: Instructions on how to bootstrap project, run ETL processes, etc.*

### Project setup instructions

After cloning the git repo:

`datakit data pull` to retrieve the data files.


*TK: For more complex or unusual projects additional directions follow*

## Data notes

*Add important caveats, limitations, and source contact info here.*
